import React, { useState, useEffect, useCallback, useMemo } from 'react';
import type { ForumPost, Challenge, WellnessDataPoint, AnalysisScores } from '../types';
import { getPosts, addPost, getLeaderboardData } from '../services/forumService';
import { getChallenges, getJoinedChallenges, joinChallenge, getUserProfile } from '../services/wellnessService';
import type { LeaderboardUser } from '../services/forumService';
import { MessageSquareIcon, LeafIcon, TrophyIcon, LeaderboardIcon } from './icons';

const timeSince = (date: string): string => {
    const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000);
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + "y";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + "mo";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + "d";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + "h";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + "m";
    return Math.floor(seconds) + "s";
}

const ChallengeDetailModal: React.FC<{ challenge: Challenge | null; onClose: () => void }> = ({ challenge, onClose }) => {
    if (!challenge) return null;

    return (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div className="interactive-card rounded-xl p-6 sm:p-8 max-w-lg w-full relative animate-slide-in" onClick={(e) => e.stopPropagation()}>
                <button onClick={onClose} className="absolute top-4 right-4 text-2xl leading-none text-[color:var(--text-secondary)] hover:text-[color:var(--text-primary)] transition rounded-full w-8 h-8 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[color:var(--accent-focus)]">&times;</button>
                <div className="flex items-center gap-4 mb-4">
                    <div className="p-3 rounded-full bg-yellow-500/10 border border-yellow-500/20">
                        <challenge.icon className="w-8 h-8 text-yellow-400" />
                    </div>
                    <div>
                        <h3 className="text-[color:var(--text-primary)]">{challenge.title}</h3>
                        <p className="text-sm font-semibold text-yellow-400">{challenge.duration}</p>
                    </div>
                </div>
                <p className="text-[color:var(--text-secondary)] mb-4">{challenge.description}</p>
                <h4 className="font-bold text-[color:var(--text-primary)] mb-2">Protocol:</h4>
                <ul className="space-y-2">
                    {challenge.details.map((item, index) => (
                        <li key={index} className="flex items-start gap-2 text-sm text-[color:var(--text-secondary)]">
                            <span className="text-cyan-400 mt-1">&#10148;</span>
                            <span>{item}</span>
                        </li>
                    ))}
                </ul>
                <button onClick={onClose} className="mt-6 w-full bg-cyan-500 text-white font-bold py-2 px-4 rounded-md shadow-md hover:bg-cyan-600 transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-cyan-500">
                    Close
                </button>
            </div>
        </div>
    );
};

interface WellnessChallengesProps {
    challengesToShow?: Challenge[];
}

const WellnessChallenges: React.FC<WellnessChallengesProps> = ({ challengesToShow }) => {
    const [challenges, setChallenges] = useState<Challenge[]>([]);
    const [joinedChallenges, setJoinedChallenges] = useState<string[]>([]);
    const [selectedChallenge, setSelectedChallenge] = useState<Challenge | null>(null);

    useEffect(() => {
        setChallenges(challengesToShow || getChallenges());
        setJoinedChallenges(getJoinedChallenges());
    }, [challengesToShow]);

    const handleJoin = (e: React.MouseEvent, challengeId: string) => {
        e.stopPropagation();
        const updatedJoined = joinChallenge(challengeId);
        setJoinedChallenges(updatedJoined);
    };

    return (
        <>
            <ChallengeDetailModal challenge={selectedChallenge} onClose={() => setSelectedChallenge(null)} />
            <div className="space-y-3">
                {challenges.map(challenge => {
                    const isJoined = joinedChallenges.includes(challenge.id);
                    return (
                        <button key={challenge.id} onClick={() => setSelectedChallenge(challenge)} className="w-full text-left bg-black/20 p-4 rounded-md flex items-center justify-between gap-4 cursor-pointer hover:bg-white/5 border border-[color:var(--text-tertiary)] hover:border-[color:var(--accent-focus)]/50 transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[color:var(--accent-focus)]">
                            <div className="flex items-start gap-3">
                                <div className={`p-2 rounded-full ${isJoined ? 'bg-black/20' : 'bg-yellow-500/10'}`}>
                                    <challenge.icon className={`w-7 h-7 ${isJoined ? 'text-slate-500' : 'text-yellow-400'}`} />
                                </div>
                                <div>
                                    <h4 className="font-semibold text-[color:var(--text-primary)]">{challenge.title}</h4>
                                    <p className="text-[color:var(--text-secondary)] text-base">{challenge.description}</p>
                                </div>
                            </div>
                            <button
                                onClick={(e) => handleJoin(e, challenge.id)}
                                disabled={isJoined}
                                className={`py-2 px-4 rounded-md text-sm font-bold transition whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-yellow-500 border ${
                                    isJoined 
                                        ? 'bg-slate-700 text-slate-400 cursor-default border-slate-600' 
                                        : 'bg-yellow-500/80 text-white hover:bg-yellow-600/80 border-yellow-400/50'
                                }`}
                            >
                                {isJoined ? 'Active' : 'Engage'}
                            </button>
                        </button>
                    );
                })}
            </div>
        </>
    );
};

const Leaderboard: React.FC = () => {
    const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([]);
    
    useEffect(() => {
        const profile = getUserProfile();
        setLeaderboard(getLeaderboardData(profile));
    }, []);

    return (
        <div className="space-y-3">
            {leaderboard.map((user) => (
                <div key={user.name} className={`p-4 rounded-md flex items-center justify-between gap-4 border ${user.name === 'You' ? 'bg-cyan-500/10 border-cyan-500/50' : 'bg-black/20 border-[color:var(--text-tertiary)]'}`}>
                    <div className="flex items-center gap-3">
                        <span className="font-bold text-lg w-6 text-[color:var(--text-secondary)]">{user.rank}</span>
                        <div>
                            <h4 className="font-semibold text-[color:var(--text-primary)]">{user.name}</h4>
                            <p className="text-[color:var(--text-secondary)] text-base">Level {user.level}</p>
                        </div>
                    </div>
                    <div className="text-right">
                        <p className="font-bold text-yellow-400" style={{textShadow: '0 0 8px rgba(234,179,8,0.5)'}}>{user.totalAp.toLocaleString()} AP</p>
                    </div>
                </div>
            ))}
        </div>
    );
};

interface ForumScreenProps {
    history: WellnessDataPoint[];
}

const ForumScreen: React.FC<ForumScreenProps> = ({ history }) => {
    const [posts, setPosts] = useState<ForumPost[]>([]);
    const [newPostContent, setNewPostContent] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [activeTab, setActiveTab] = useState<'community' | 'leaderboard'>('community');

    const suggestedChallenges = useMemo(() => {
        const latestAnalysis = history.length > 0 ? history[history.length - 1] : null;
        if (!latestAnalysis) return [];

        const scores = latestAnalysis.scores;
        const lowestScoreCategory = (Object.keys(scores) as Array<keyof AnalysisScores>).reduce((a, b) => scores[a] < scores[b] ? a : b);
        
        const allChallenges = getChallenges();
        const joined = getJoinedChallenges();

        const categoryToChallengeMap: { [key: string]: string[] } = {
            nutrition: ['mindful_eating_week'],
            hydration: ['hydration_challenge_month'],
            sleep: ['digital_detox_weekend'],
            stress: ['digital_detox_weekend', 'mindful_eating_week'],
        };
        
        const suggestedIds = categoryToChallengeMap[lowestScoreCategory] || [];
        
        return allChallenges.filter(c => suggestedIds.includes(c.id) && !joined.includes(c.id));

    }, [history]);

    useEffect(() => {
        setPosts(getPosts());
    }, []);

    const handlePostSubmit = useCallback((e: React.FormEvent) => {
        e.preventDefault();
        if (!newPostContent.trim() || isSubmitting) return;

        setIsSubmitting(true);
        setTimeout(() => {
            const updatedPosts = addPost(newPostContent);
            setPosts(updatedPosts);
            setNewPostContent('');
            setIsSubmitting(false);
        }, 500);
    }, [newPostContent, isSubmitting]);

    const renderCommunityContent = () => (
        <>
            {suggestedChallenges.length > 0 && (
                <div className="interactive-card rounded-xl p-6 sm:p-8 mb-8 border-2 border-yellow-500/50 bg-yellow-500/10">
                    <h3 className="mb-4 flex items-center gap-2">
                        <TrophyIcon className="w-6 h-6 text-yellow-400" />
                        Recommended Directive
                    </h3>
                    <p className="text-[color:var(--text-secondary)] mb-4 text-base">Based on your recent analysis, this challenge is a priority objective.</p>
                    <WellnessChallenges challengesToShow={suggestedChallenges} />
                </div>
            )}

            <div className="interactive-card rounded-xl p-6 sm:p-8 mb-8">
                <h3 className="mb-4 flex items-center gap-2">
                    <TrophyIcon className="w-6 h-6 text-yellow-400" />
                    All Community Directives
                </h3>
                <WellnessChallenges />
            </div>
            
            <div className="interactive-card rounded-xl p-6 sm:p-8">
                <h3 className="mb-4">Data Stream</h3>
                <form onSubmit={handlePostSubmit} className="mb-6 bg-black/20 p-4 rounded-md">
                    <textarea value={newPostContent} onChange={(e) => setNewPostContent(e.target.value)} placeholder="Share intel, ask a question..." className="w-full p-2 border border-[color:var(--text-tertiary)] rounded-md bg-black/30 focus:ring-2 focus:ring-[color:var(--accent-focus)] focus:outline-none transition" rows={3} />
                    <div className="flex justify-end mt-3">
                        <button type="submit" disabled={!newPostContent.trim() || isSubmitting} className="bg-cyan-500 text-white font-bold py-2 px-5 rounded-md shadow-md hover:bg-cyan-600 transition disabled:bg-slate-600 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500">
                            {isSubmitting ? 'Transmitting...' : 'Transmit'}
                        </button>
                    </div>
                </form>

                <div className="space-y-4">
                    {posts.map(post => (
                        <div key={post.id} className="bg-black/20 p-4 rounded-md border border-[color:var(--text-tertiary)]">
                            <div className="flex justify-between items-start">
                                <p className="font-semibold text-cyan-400">{post.author}</p>
                                <span className="text-xs text-[color:var(--text-secondary)]">{timeSince(post.timestamp)}</span>
                            </div>
                            <p className="mt-3 text-[color:var(--text-secondary)] whitespace-pre-wrap">{post.content}</p>
                        </div>
                    ))}
                </div>
            </div>
        </>
    );

    const renderLeaderboardContent = () => (
        <div className="interactive-card rounded-xl p-6 sm:p-8">
            <h3 className="mb-4 flex items-center gap-2">
                <LeaderboardIcon className="w-6 h-6 text-yellow-400" />
                Top Agents
            </h3>
            <Leaderboard />
        </div>
    );

    return (
        <div className="w-full">
            <h2 className="glitch mb-2 text-center" data-text="Community Hub">Community Hub</h2>
            <p className="text-lg text-[color:var(--text-secondary)] mb-6 text-center">Share intel, join directives, and connect with other agents.</p>
            
            <div className="mb-6 flex justify-center">
                <div className="bg-black/20 p-1 rounded-lg flex gap-1 border border-[color:var(--text-tertiary)]">
                    <button onClick={() => setActiveTab('community')} className={`px-4 py-2 text-sm font-semibold rounded-md transition ${activeTab === 'community' ? 'bg-black/30 text-[color:var(--accent-focus)] shadow-[inset_0_1px_2px_rgba(0,0,0,0.5),0_0_8px_var(--accent-focus)]' : 'text-[color:var(--text-secondary)]'} focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[color:var(--accent-focus)]`}>Community</button>
                    <button onClick={() => setActiveTab('leaderboard')} className={`px-4 py-2 text-sm font-semibold rounded-md transition ${activeTab === 'leaderboard' ? 'bg-black/30 text-[color:var(--accent-focus)] shadow-[inset_0_1px_2px_rgba(0,0,0,0.5),0_0_8px_var(--accent-focus)]' : 'text-[color:var(--text-secondary)]'} focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[color:var(--accent-focus)]`}>Leaderboard</button>
                </div>
            </div>

            {activeTab === 'community' ? renderCommunityContent() : renderLeaderboardContent()}
        </div>
    );
};

export default ForumScreen;