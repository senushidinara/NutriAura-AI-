import React from 'react';
import type { WellnessDataPoint } from '../types';
import { ChartBarIcon, CircuitryIcon, CrescentMoonIcon, HeartRateIcon, WaterMoleculeIcon } from './icons';

interface LineChartProps {
    data: { value: number; label: string }[];
    category: 'nutrition' | 'sleep' | 'stress' | 'hydration';
    label: string;
    Icon: React.ElementType;
}

const LineChart: React.FC<LineChartProps> = ({ data, category, label, Icon }) => {
    if (data.length < 2) {
        return (
            <div className="h-48 flex items-center justify-center bg-black/5 dark:bg-black/20 rounded-md">
                <p className="text-sm text-[color:var(--text-secondary)]">Not enough data to render trend line.</p>
            </div>
        );
    }

    const width = 300;
    const height = 150;
    const padding = 20;
    const maxY = 100;
    const xStep = (width - padding * 2) / (data.length - 1);

    const points = data.map((point, i) => {
        const x = padding + i * xStep;
        const y = height - padding - (point.value / maxY) * (height - padding * 2);
        return `${x},${y}`;
    }).join(' ');

    const areaPoints = `${padding},${height} ${points} ${padding + (data.length - 1) * xStep},${height}`;

    const gradientIdArea = `gradient-area-${category}`;
    const gradientIdLine = `gradient-line-${category}`;
    const fromColorVar = `var(--${category}-grad-from)`;
    const toColorVar = `var(--${category}-grad-to)`;
    const textColorVar = `var(--${category}-text)`;

    return (
        <div className="bg-black/5 dark:bg-black/20 p-4 rounded-md border border-[color:var(--card-border)]">
            <h4 className={`font-semibold mb-2 flex items-center gap-2`} style={{ color: textColorVar }}>
                <Icon className={`w-5 h-5`} />
                {label} Trend
            </h4>
            <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto">
                <defs>
                    <linearGradient id={gradientIdArea} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={fromColorVar} stopOpacity="0.4" />
                        <stop offset="100%" stopColor={toColorVar} stopOpacity="0" />
                    </linearGradient>
                    <linearGradient id={gradientIdLine} x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor={fromColorVar} />
                        <stop offset="100%" stopColor={toColorVar} />
                    </linearGradient>
                </defs>

                <polyline
                    fill={`url(#${gradientIdArea})`}
                    points={areaPoints}
                />
                 <polyline
                    fill="none"
                    stroke={`url(#${gradientIdLine})`}
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    points={points}
                    className="chart-line"
                    style={{ filter: `drop-shadow(0 2px 5px ${fromColorVar})` }}
                />

                {data.map((point, i) => {
                    const x = padding + i * xStep;
                    const y = height - padding - (point.value / maxY) * (height - padding * 2);
                    return (
                        <g key={i}>
                            <circle cx={x} cy={y} r="3" fill={toColorVar} className="chart-dot" />
                            <title>{`Score: ${point.value} on ${point.label}`}</title>
                        </g>
                    );
                })}
            </svg>
             <style>{`
                .chart-line {
                    stroke-dasharray: 1000;
                    stroke-dashoffset: 1000;
                    animation: dash 1.5s ease-out forwards;
                }
                .chart-dot {
                    opacity: 0;
                    animation: fade-in 0.5s ease-out forwards;
                    animation-delay: 1.2s;
                }
                @keyframes dash { to { stroke-dashoffset: 0; } }
                @keyframes fade-in { to { opacity: 1; } }
            `}</style>
        </div>
    );
};


interface ProgressScreenProps {
    history: WellnessDataPoint[];
}

const ProgressScreen: React.FC<ProgressScreenProps> = ({ history }) => {
    const chartData = (key: 'nutrition' | 'sleep' | 'stress' | 'hydration') => {
        return history.map(item => ({
            value: item.scores[key],
            label: new Date(item.timestamp).toLocaleDateString(),
        }));
    };
    
    return (
        <div className="w-full">
            <h2 className="glitch text-3xl font-bold mb-2 text-center flex items-center justify-center gap-2" data-text="Progress Matrix">
                <ChartBarIcon className="w-8 h-8"/>
                Progress Matrix
            </h2>
            <p className="text-lg text-[color:var(--text-secondary)] mb-6 text-center">Track your wellness data over time.</p>

            <div className="interactive-card">
                {history.length === 0 ? (
                    <div className="text-center p-8">
                        <p className="text-[color:var(--text-secondary)]">No historical data available.</p>
                        <p className="text-sm text-[color:var(--text-tertiary)] mt-2">Complete your first analysis to begin data logging.</p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        <LineChart data={chartData('nutrition')} category="nutrition" label="Nutrition" Icon={CircuitryIcon} />
                        <LineChart data={chartData('sleep')} category="sleep" label="Sleep" Icon={CrescentMoonIcon} />
                        <LineChart data={chartData('stress')} category="stress" label="Stress" Icon={HeartRateIcon} />
                        <LineChart data={chartData('hydration')} category="hydration" label="Hydration" Icon={WaterMoleculeIcon} />
                    </div>
                )}
            </div>
        </div>
    );
};

export default ProgressScreen;