import React, { useState, useMemo } from 'react';
import type { AnalysisResult, Goal } from '../types';
import { CircuitryIcon, CrescentMoonIcon, HeartRateIcon, WaterMoleculeIcon, RestartIcon, TargetIcon, ShareIcon, AuraPointsIcon, PizzaIcon, LinkIcon, BookOpenIcon } from './icons';

interface ResultsScreenProps {
  result: AnalysisResult;
  goals: Goal[];
  onGoalsUpdate: (goals: Goal[]) => void;
  onReset: () => void;
  isChaosMode: boolean;
}

const iconMap: { [key: string]: React.ReactElement<{ className?: string }> } = {
  circuitry: <CircuitryIcon className="w-6 h-6" />,
  crescent_moon: <CrescentMoonIcon className="w-6 h-6" />,
  heart_rate: <HeartRateIcon className="w-6 h-6" />,
  water_molecule: <WaterMoleculeIcon className="w-6 h-6" />,
  general: <TargetIcon className="w-6 h-6" />,
  pizza: <PizzaIcon className="w-6 h-6" />,
};

const ShareGoalModal: React.FC<{ goal: Goal | null; onClose: () => void; }> = ({ goal, onClose }) => {
    if (!goal) return null;

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div className="interactive-card rounded-lg p-6 max-w-sm w-full text-center relative animate-slide-in" onClick={(e) => e.stopPropagation()}>
                <button onClick={onClose} className="absolute top-2 right-2 text-2xl leading-none text-[color:var(--text-secondary)] hover:opacity-70 rounded-full w-8 h-8 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-current">&times;</button>
                <h2 className="text-4xl font-extrabold uppercase tracking-widest mb-4 text-yellow-400" style={{ textShadow: '0 0 8px rgba(234,179,8,0.7)'}}>Directive</h2>
                <div className="w-24 h-24 mx-auto mb-4 bg-yellow-500/10 rounded-full flex items-center justify-center border-2 border-yellow-400/50">
                    {React.cloneElement(iconMap[goal.category], { className: "w-12 h-12" })}
                </div>
                <p className="text-lg mb-2 font-semibold">Objective Acquired:</p>
                <p className="text-xl font-bold mb-4 bg-black/30 p-2 rounded">{goal.text}</p>
                <p className="font-bold text-xl uppercase">Reward</p>
                <p className="text-lg">Enhanced System Performance</p>
                <div className="mt-4 text-xs uppercase text-[color:var(--text-tertiary)]">Issued by NutriAura AI Core</div>
            </div>
        </div>
    );
};

const ScoreRing: React.FC<{ score: number; label: string, category: 'nutrition' | 'sleep' | 'stress' | 'hydration' }> = ({ score, label, category }) => {
    const radius = 52;
    const circumference = 2 * Math.PI * radius;
    const [offset, setOffset] = useState(circumference);
    
    React.useEffect(() => {
        const progress = circumference - (score / 100) * circumference;
        const timer = setTimeout(() => setOffset(progress), 100);
        return () => clearTimeout(timer);
    }, [score, circumference]);
    
    const gradientId = `gradient-${category}`;
    const fromColorVar = `var(--${category}-grad-from)`;
    const toColorVar = `var(--${category}-grad-to)`;
    const textColorVar = `var(--${category}-text)`;

    return (
        <div className="flex flex-col items-center justify-center relative">
            <svg className="w-32 h-32 transform -rotate-90">
                 <defs>
                    <linearGradient id={gradientId} x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor={fromColorVar} />
                      <stop offset="100%" stopColor={toColorVar} />
                    </linearGradient>
                </defs>
                <circle className="stroke-current text-black/10 dark:text-[color:var(--text-tertiary)]" strokeWidth="8" fill="transparent" r={radius} cx="64" cy="64" />
                <circle
                    stroke={`url(#${gradientId})`}
                    style={{ 
                        strokeDashoffset: offset, 
                        transition: 'stroke-dashoffset 1.5s cubic-bezier(0.65, 0, 0.35, 1)', 
                        filter: `drop-shadow(0 0 5px ${toColorVar})` 
                    }}
                    strokeWidth="8"
                    strokeDasharray={circumference}
                    strokeLinecap="round"
                    fill="transparent"
                    r={radius}
                    cx="64"
                    cy="64"
                />
            </svg>
            <div className="absolute flex flex-col items-center font-sans">
                <span className="text-3xl font-bold" style={{color: textColorVar, textShadow: `0 0 10px ${toColorVar}`}}>{score}</span>
                <span className="text-xs font-medium text-[color:var(--text-secondary)] uppercase tracking-wider">{label}</span>
            </div>
        </div>
    );
};

const GroundingAttribution: React.FC<{ attribution: AnalysisResult['groundingAttribution'] }> = ({ attribution }) => {
    if (!attribution || attribution.length === 0) return null;

    const sources = attribution.map(chunk => chunk.web || chunk.maps).filter((source): source is { uri: string; title: string; } => !!source);
    if (sources.length === 0) return null;

    return (
        <div className="mt-8 border-t border-[color:var(--card-border)] pt-6">
            <h3 className="mb-2 flex items-center gap-2 text-[color:var(--text-secondary)]">
                <LinkIcon className="w-5 h-5" />
                Data Sources
            </h3>
            <div className="bg-black/5 dark:bg-black/20 p-4 rounded-md text-sm space-y-2">
                {sources.map((source, index) => (
                    <a 
                        key={index}
                        href={source.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block text-[color:var(--accent-primary-to)] hover:underline truncate rounded focus-visible:outline-none focus-visible:ring-1 ring-[color:var(--accent-focus)]"
                        title={source.uri}
                    >
                        {source.title || source.uri}
                    </a>
                ))}
            </div>
            <p className="text-xs text-[color:var(--text-tertiary)] mt-2 text-center">
                Directives augmented by Google Search and Maps for real-time data integration.
            </p>
        </div>
    );
};

const GoalSetter: React.FC<{ result: AnalysisResult; goals: Goal[]; onGoalsUpdate: (goals: Goal[]) => void; onShare: (goal: Goal) => void; }> = ({ result, goals, onGoalsUpdate, onShare }) => {
    const [customGoal, setCustomGoal] = useState('');

    const suggestedGoals = useMemo(() => {
        const sortedScores = (Object.keys(result.scores) as Array<keyof typeof result.scores>)
            .sort((a, b) => result.scores[a] - result.scores[b]);
        
        const suggestions = {
            sleep: "Get 7-8 hours of quality sleep.",
            stress: "Practice 5 minutes of mindfulness daily.",
            nutrition: "Add a serving of greens to one meal daily.",
            hydration: "Drink 8 glasses of water a day."
        };

        return sortedScores.slice(0, 2).map(key => ({
            text: suggestions[key],
            category: key,
        }));

    }, [result.scores]);

    const handleAddGoal = (text: string, category: Goal['category']) => {
        if (!text.trim()) return;
        const newGoal: Goal = {
            id: new Date().toISOString(),
            text,
            category,
            completed: false,
        };
        onGoalsUpdate([...goals, newGoal]);
    };

    const handleAddCustomGoal = (e: React.FormEvent) => {
        e.preventDefault();
        handleAddGoal(customGoal, 'general');
        setCustomGoal('');
    };

    const handleToggleGoal = (id: string) => {
        const updatedGoals = goals.map(g => g.id === id ? { ...g, completed: !g.completed } : g);
        onGoalsUpdate(updatedGoals);
    };

    const handleDeleteGoal = (id: string) => {
        onGoalsUpdate(goals.filter(g => g.id !== id));
    };

    return (
        <div>
            <h3 className="mb-4 flex items-center gap-2">
                <TargetIcon className="w-6 h-6 text-yellow-400" />
                Set Directives
            </h3>
            <div className="bg-black/5 dark:bg-black/20 p-4 rounded-md shadow-inner">
                <h4 className="font-semibold mb-2">Suggested Directives</h4>
                <div className="flex flex-col sm:flex-row gap-2 mb-4">
                    {suggestedGoals.map(sg => (
                        <button key={sg.text} onClick={() => handleAddGoal(sg.text, sg.category as Goal['category'])} className="flex-1 text-left text-base p-2 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-md transition text-[color:var(--accent-primary-to)] focus-visible:outline-none focus-visible:ring-2 ring-[color:var(--accent-focus)]">
                           + {sg.text}
                        </button>
                    ))}
                </div>
                
                <h4 className="font-semibold mb-2">Active Directives</h4>
                <div className="space-y-2 mb-4">
                    {goals.length > 0 ? goals.map(goal => (
                        <div key={goal.id} className="flex items-center justify-between p-2 bg-black/10 dark:bg-black/30 rounded-md group">
                            <div className="flex items-center">
                                <input type="checkbox" id={`goal-${goal.id}`} checked={goal.completed} onChange={() => handleToggleGoal(goal.id)} className="w-4 h-4 text-[color:var(--accent-primary-to)] bg-gray-200 dark:bg-gray-700 border-gray-400 dark:border-gray-600 rounded focus:ring-[color:var(--accent-primary-to)]" />
                                <label htmlFor={`goal-${goal.id}`} className={`ml-3 text-base ${goal.completed ? 'line-through text-[color:var(--text-tertiary)]' : 'text-[color:var(--text-secondary)]'}`}>{goal.text}</label>
                            </div>
                            <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onClick={() => onShare(goal)} className="p-1 text-gray-500 dark:text-slate-400 hover:text-[color:var(--accent-primary-to)] rounded-full focus-visible:outline-none focus-visible:ring-2 ring-[color:var(--accent-focus)]" title="Share Goal"><ShareIcon className="w-4 h-4" /></button>
                                <button onClick={() => handleDeleteGoal(goal.id)} className="p-1 text-gray-500 dark:text-slate-400 hover:text-red-500 rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500" title="Remove Goal">&times;</button>
                            </div>
                        </div>
                    )) : <p className="text-base text-[color:var(--text-secondary)]">No directives set. Add one!</p>}
                </div>

                <form onSubmit={handleAddCustomGoal} className="flex gap-2">
                    <input type="text" value={customGoal} onChange={(e) => setCustomGoal(e.target.value)} placeholder="Add a custom directive..." className="flex-grow p-2 border border-[color:var(--card-border)] rounded-md bg-white/50 dark:bg-black/30 focus:ring-2 ring-[color:var(--accent-focus)] focus:outline-none transition text-base" />
                    <button type="submit" className="bg-gradient-to-r from-[color:var(--accent-primary-from)] to-[color:var(--accent-primary-to)] text-white font-bold py-2 px-4 rounded-md shadow-md hover:opacity-90 transition disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 ring-[color:var(--accent-focus)]" disabled={!customGoal.trim()}>Add</button>
                </form>
            </div>
        </div>
    );
};

const ResultsScreen: React.FC<ResultsScreenProps> = ({ result, goals, onGoalsUpdate, onReset, isChaosMode }) => {
  const [showApNotification, setShowApNotification] = useState(true);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [selectedGoalToShare, setSelectedGoalToShare] = useState<Goal | null>(null);
  const [expandedItems, setExpandedItems] = useState<Record<string, boolean>>({});

  const toggleExpand = (id: string) => {
    setExpandedItems(prev => ({ ...prev, [id]: !prev[id] }));
  };

  React.useEffect(() => {
    const timer = setTimeout(() => setShowApNotification(false), 4000);
    return () => clearTimeout(timer);
  }, []);

  const handleShareGoal = (goal: Goal) => {
    setSelectedGoalToShare(goal);
    setIsShareModalOpen(true);
  };
  
  const modifiedResult = useMemo(() => {
    if (!isChaosMode) return result;

    const chaoticResult = JSON.parse(JSON.stringify(result));

    chaoticResult.keyFindings.unshift({
        title: "Cosmic Pizza Alignment",
        description: "Your biometric scan indicates a severe deficiency in cheese and pepperoni. This is a critical system anomaly.",
        icon: 'pizza',
        deepDive: "According to corrupted data files from a 1980s arcade machine, pizza aligns your energy matrix with the cosmic oven, leading to a 1-UP. Or at least, a food coma."
    });
    
    chaoticResult.recommendations.unshift({
        title: "Embrace the Chaos",
        description: "Sometimes, the best algorithm is no algorithm. Your aura suggests a dose of pure, unadulterated entropy.",
        items: [
            "Initiate pizza protocol for breakfast.",
            "Wear mismatched socks to confuse facial recognition systems.",
            "Replace one workout with a spontaneous dance party subroutine."
        ],
        deepDive: "Chaos Theory suggests that small, unpredictable actions can lead to large, unforeseen positive outcomes. Like finding an extra slice of pizza you forgot about."
    });

    return chaoticResult;
  }, [result, isChaosMode]);

  const findingIconMap = {
    circuitry: <CircuitryIcon className="w-8 h-8 text-[color:var(--nutrition-text)]" />,
    crescent_moon: <CrescentMoonIcon className="w-8 h-8 text-[color:var(--sleep-text)]" />,
    heart_rate: <HeartRateIcon className="w-8 h-8 text-[color:var(--stress-text)]" />,
    water_molecule: <WaterMoleculeIcon className="w-8 h-8 text-[color:var(--hydration-text)]" />,
    pizza: <PizzaIcon className="w-8 h-8 text-yellow-400" />,
  };


  return (
    <div className="w-full max-w-2xl mx-auto">
      {showApNotification && (
         <div className="fixed top-20 left-1/2 -translate-x-1/2 bg-yellow-400/90 text-slate-900 font-bold py-2 px-4 rounded-md shadow-lg z-20 flex items-center gap-2 animate-slide-in backdrop-blur-sm border border-yellow-300">
            <AuraPointsIcon className="w-5 h-5" />
            <span>+100 Aura Points Acquired</span>
         </div>
      )}
      <ShareGoalModal goal={selectedGoalToShare} onClose={() => setIsShareModalOpen(false)} />

      <div className="interactive-card">
        <h2 className="glitch mb-2 text-center" data-text={isChaosMode ? "Chaotic Matrix" : "Wellness Matrix"}>
          {isChaosMode ? "Chaotic Matrix" : "Wellness Matrix"}
        </h2>
        <p className="text-lg text-[color:var(--text-secondary)] mb-6 text-center">Biometric analysis complete. Here is your data readout.</p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8 bg-black/5 dark:bg-black/20 p-4 rounded-md shadow-inner">
          <ScoreRing score={modifiedResult.scores.nutrition} label="Nutrition" category="nutrition" />
          <ScoreRing score={modifiedResult.scores.sleep} label="Sleep" category="sleep" />
          <ScoreRing score={modifiedResult.scores.stress} label="Stress" category="stress" />
          <ScoreRing score={modifiedResult.scores.hydration} label="Hydration" category="hydration" />
        </div>

        <div className="mb-8">
          <h3 className="mb-4">Bio-Signatures</h3>
          <div className="space-y-3">
            {modifiedResult.keyFindings.map((finding, index) => (
              <div key={index} className="bg-black/5 dark:bg-black/20 p-4 rounded-md">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 bg-black/5 dark:bg-black/20 p-3 rounded-full shadow-sm">{findingIconMap[finding.icon as keyof typeof findingIconMap]}</div>
                  <div className="flex-grow">
                    <h4 className="font-semibold">{finding.title}</h4>
                    <p className="text-[color:var(--text-secondary)] text-base">{finding.description}</p>
                  </div>
                </div>
                {finding.deepDive && (
                    <div className="mt-3">
                        <button onClick={() => toggleExpand(`finding-${index}`)} className="text-sm font-semibold text-[color:var(--accent-primary-to)] flex items-center gap-1 hover:underline rounded focus-visible:outline-none focus-visible:ring-2 ring-[color:var(--accent-focus)]">
                            <BookOpenIcon className="w-4 h-4" />
                            <span>{expandedItems[`finding-${index}`] ? 'Collapse Details' : 'Deep Dive'}</span>
                        </button>
                        <div className={`grid transition-all duration-300 ease-in-out ${expandedItems[`finding-${index}`] ? 'grid-rows-[1fr] opacity-100 mt-2' : 'grid-rows-[0fr] opacity-0'}`}>
                            <div className="overflow-hidden">
                                <p className="p-3 bg-black/10 dark:bg-black/30 rounded-md text-sm text-[color:var(--text-secondary)]">
                                    {finding.deepDive}
                                </p>
                            </div>
                        </div>
                    </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
      
       <div className="my-8 interactive-card">
        <h3 className="mb-4">Personalized Directives</h3>
         <div className="space-y-4">
            {modifiedResult.recommendations.map((rec, index) => (
                <div key={index} className="bg-black/5 dark:bg-black/20 p-4 rounded-md">
                    <h4 className="font-bold mb-2">{rec.title}</h4>
                    <p className="text-base text-[color:var(--text-secondary)] mb-3">{rec.description}</p>
                    <ul className="space-y-2">
                        {rec.items.map((item, itemIndex) => (
                            <li key={itemIndex} className="flex items-start gap-2 text-base text-[color:var(--text-secondary)]">
                                <span className="text-[color:var(--accent-primary-to)] mt-1">&#10148;</span>
                                <span>{item}</span>
                            </li>
                        ))}
                    </ul>
                    {rec.deepDive && (
                        <div className="mt-4">
                            <button onClick={() => toggleExpand(`rec-${index}`)} className="text-sm font-semibold text-[color:var(--accent-primary-to)] flex items-center gap-1 hover:underline rounded focus-visible:outline-none focus-visible:ring-2 ring-[color:var(--accent-focus)]">
                                <BookOpenIcon className="w-4 h-4" />
                                <span>{expandedItems[`rec-${index}`] ? 'Collapse Details' : 'Deep Dive'}</span>
                            </button>
                            <div className={`grid transition-all duration-300 ease-in-out ${expandedItems[`rec-${index}`] ? 'grid-rows-[1fr] opacity-100 mt-2' : 'grid-rows-[0fr] opacity-0'}`}>
                                <div className="overflow-hidden">
                                    <p className="p-3 bg-black/10 dark:bg-black/30 rounded-md text-sm text-[color:var(--text-secondary)]">
                                        {rec.deepDive}
                                    </p>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            ))}
         </div>
      </div>
      
      <div className="interactive-card">
        <GoalSetter result={modifiedResult} goals={goals} onGoalsUpdate={onGoalsUpdate} onShare={handleShareGoal} />
        <GroundingAttribution attribution={result.groundingAttribution} />
      </div>

      <button
        onClick={onReset}
        className="w-full mt-8 bg-black/5 text-[color:var(--text-primary)] font-bold py-3 px-6 rounded-lg shadow-lg hover:bg-black/10 transition-all transform hover:scale-105 focus-visible:outline-none focus-visible:ring-4 ring-[color:var(--accent-focus)] flex items-center justify-center gap-2 border border-[color:var(--card-border)] backdrop-blur-sm"
      >
        <RestartIcon className="w-5 h-5"/>
        <span className="text-lg">Re-Analyze</span>
      </button>
    </div>
  );
};

export default ResultsScreen;