import React, { useState, useCallback, useEffect, useRef } from 'react';
import type { QuizAnswers } from '../types';
import { DietHealthyIcon, DietAverageIcon, DietUnhealthyIcon, ActivitySedentaryIcon, ActivityLightIcon, ActivityModerateIcon, ActivityActiveIcon, CheckCircleIcon, MicrophoneIcon } from './icons';
import Stepper from './Stepper';

// Augment the window type for SpeechRecognition
interface SpeechRecognition {
  continuous: boolean;
  lang: string;
  interimResults: boolean;
  onresult: (event: any) => void;
  onerror: (event: any) => void;
  onend: () => void;
  start: () => void;
  stop: () => void;
}
declare global {
  interface Window {
    SpeechRecognition: new () => SpeechRecognition;
    webkitSpeechRecognition: new () => SpeechRecognition;
  }
}

interface LifestyleQuizProps {
  onSubmit: (answers: QuizAnswers) => void;
}

const dietOptions = [
  { value: 'Very Healthy', label: 'Optimized', icon: DietHealthyIcon },
  { value: 'Mostly Healthy', label: 'Balanced', icon: DietHealthyIcon },
  { value: 'Average', label: 'Standard', icon: DietAverageIcon },
  { value: 'Unhealthy', label: 'Sub-Optimal', icon: DietUnhealthyIcon },
];

const activityOptions = [
  { value: 'Sedentary', label: 'Sedentary', icon: ActivitySedentaryIcon },
  { value: 'Light', label: 'Light', icon: ActivityLightIcon },
  { value: 'Moderate', label: 'Moderate', icon: ActivityModerateIcon },
  { value: 'Very Active', label: 'High-Output', icon: ActivityActiveIcon },
];

const RadioCardGroup: React.FC<{
  options: { value: string; label: string; icon: React.ElementType }[];
  selectedValue: string;
  onChange: (value: string) => void;
}> = ({ options, selectedValue, onChange }) => (
  <div className="grid grid-cols-2 gap-3">
    {options.map(({ value, label, icon: Icon }) => {
      const isSelected = selectedValue === value;
      return (
        <button
          type="button"
          key={value}
          onClick={() => onChange(value)}
          className={`relative p-3 rounded-lg text-base transform transition-all duration-300 font-semibold flex flex-col items-center justify-center border focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-black focus-visible:ring-[color:var(--accent-focus)]
            ${isSelected
              ? 'scale-105 text-white border-transparent shadow-[0_0_20px_var(--accent-primary-from)]'
              : 'bg-black/20 text-[color:var(--text-secondary)] border-[color:var(--text-tertiary)] hover:scale-[1.02] hover:bg-white/5 hover:border-[color:var(--accent-focus)]'
          }`}
        >
          {isSelected && <div className="absolute -inset-px rounded-lg bg-gradient-to-r from-[color:var(--accent-primary-from)] to-[color:var(--accent-primary-to)] -z-10 opacity-70"></div>}
          {isSelected && <CheckCircleIcon className="absolute top-2 right-2 w-5 h-5 text-[color:var(--accent-focus)] animate-pop-in" />}
          <Icon className={`w-8 h-8 mb-1 transition-colors ${isSelected ? 'text-[color:var(--accent-focus)]' : 'text-[color:var(--text-tertiary)]'}`} />
          <span>{label}</span>
        </button>
      );
    })}
  </div>
);

const RangeSlider: React.FC<{
  id: string;
  label: string;
  min: number;
  max: number;
  step?: number;
  value: number;
  onChange: (value: number) => void;
  unit?: string;
}> = ({ id, label, min, max, step = 1, value, onChange, unit = '' }) => {
  const [isChanging, setIsChanging] = useState(false);
  const progress = ((value - min) / (max - min)) * 100;
  const sliderThumbClass = "appearance-none w-6 h-6 bg-white rounded-full shadow-md cursor-pointer focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-[color:var(--accent-focus)]";

  const handleValueChange = (newValue: number) => {
    onChange(newValue);
    if (navigator.vibrate) {
      navigator.vibrate(10); // Haptic feedback
    }
    setIsChanging(true);
    setTimeout(() => setIsChanging(false), 200);
  };

  return (
    <div>
      <label htmlFor={id} className="block text-md font-medium text-[color:var(--text-secondary)]">{label}</label>
      <div className="flex items-center gap-4 mt-2">
        <div className="relative w-full flex items-center">
            <div className="absolute h-1.5 w-full bg-black/20 rounded-full border border-[color:var(--text-tertiary)]"></div>
            <div 
                className="absolute h-1.5 bg-gradient-to-r from-[color:var(--accent-primary-from)] to-[color:var(--accent-primary-to)] rounded-full" 
                style={{ width: `${progress}%`, boxShadow: `0 0 10px var(--accent-primary-from), 0 0 10px var(--accent-primary-to)` }}
            ></div>
            <input
              type="range"
              id={id}
              min={min}
              max={max}
              step={step}
              value={value}
              onChange={(e) => handleValueChange(step === 1 ? parseInt(e.target.value, 10) : parseFloat(e.target.value))}
              className={`relative w-full h-2 bg-transparent appearance-none cursor-pointer focus-visible:outline-none [&::-webkit-slider-thumb]:${sliderThumbClass} [&::-moz-range-thumb]:${sliderThumbClass}`}
            />
        </div>
        <span className={`font-bold font-sans bg-white/10 text-white rounded-md py-1 px-2 w-24 text-center transition-transform duration-200 border border-white/20 ${isChanging ? 'scale-110' : 'scale-100'}`}>
          {step === 1 ? value : value.toFixed(1)} {unit}
        </span>
      </div>
    </div>
  );
};


const LifestyleQuiz: React.FC<LifestyleQuizProps> = ({ onSubmit }) => {
  const [answers, setAnswers] = useState<QuizAnswers>({
    sleepHours: 7,
    stressLevel: 3,
    energyLevel: 3,
    dietQuality: 'Average',
    hydration: 'Some water',
    activityLevel: 'Moderate'
  });
  const [isListening, setIsListening] = useState(false);
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const handleChange = useCallback((field: keyof QuizAnswers, value: any) => {
    setAnswers(prev => ({ ...prev, [field]: value }));
  }, []);

  const processVoiceCommand = useCallback((command: string) => {
    let commandProcessed = false;
    const commandLower = command.toLowerCase();
    
    const allOptions = [
        ...dietOptions.map(o => ({ ...o, category: 'dietQuality' as const })),
        ...activityOptions.map(o => ({...o, category: 'activityLevel' as const}))
    ];

    for(const option of allOptions) {
        if (commandLower.includes(option.label.toLowerCase())) {
            handleChange(option.category, option.value);
            commandProcessed = true;
            break;
        }
    }

    if (!commandProcessed) {
        setVoiceError("Command not recognized. Try 'Standard diet' or 'Light activity'.");
    } else {
        setVoiceError(null);
    }
}, [handleChange]);

  useEffect(() => {
    const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognitionAPI) {
        console.warn("Speech recognition is not supported by this browser.");
        return;
    }

    const recognition = new SpeechRecognitionAPI();
    recognition.continuous = false;
    recognition.lang = 'en-US';
    recognition.interimResults = false;

    recognition.onresult = (event: any) => {
        const transcript = event.results[event.results.length - 1][0].transcript.trim().toLowerCase();
        processVoiceCommand(transcript);
    };

    recognition.onerror = (event: any) => {
        if (event.error === 'not-allowed') {
            setVoiceError("Microphone access denied. Please allow access in browser settings.");
        } else {
            setVoiceError(`Speech recognition error: ${event.error}`);
        }
        setIsListening(false);
    };

    recognition.onend = () => {
        setIsListening(false);
    };

    recognitionRef.current = recognition;
}, [processVoiceCommand]);

 const handleToggleListening = () => {
    const recognition = recognitionRef.current;
    if (!recognition) {
        setVoiceError("Speech recognition module offline.");
        return;
    }

    if (isListening) {
        recognition.stop();
    } else {
        setVoiceError(null);
        try {
            recognition.start();
            setIsListening(true);
        } catch (e) {
            console.error("Could not start recognition:", e);
            setVoiceError("Could not initialize voice input.");
            setIsListening(false);
        }
    }
};

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(answers);
  };
  
  return (
    <div className="w-full interactive-card">
      <Stepper currentStep={2} />
       <div className="relative mt-4 mb-2 text-center">
            <h2 className="glitch" data-text="Lifestyle Data">Lifestyle Data</h2>
            <p className="text-lg text-[color:var(--text-secondary)]">Input data on recent lifestyle habits. Honesty is optimal.</p>
            <div className="absolute top-0 right-0">
                <button
                    type="button"
                    onClick={handleToggleListening}
                    className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[color:var(--accent-focus)] backdrop-blur-sm border ${
                        isListening ? 'bg-[color:var(--accent-focus)]/80 text-white animate-pulse-ring border-[color:var(--accent-focus)]/30' : 'bg-black/20 text-[color:var(--text-secondary)] hover:bg-white/10 border-[color:var(--text-tertiary)]'
                    }`}
                    aria-label={isListening ? 'Stop listening' : 'Start voice input'}
                >
                    <MicrophoneIcon className="w-6 h-6" />
                </button>
            </div>
        </div>

        <div className="text-center h-10 mb-2 flex items-center justify-center">
            {voiceError && <p className="text-sm text-red-400">{voiceError}</p>}
            {isListening && <p className="aurora-text font-semibold animate-pulse">Listening...</p>}
        </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <RangeSlider 
            id="sleep"
            label="Average sleep cycles?"
            min={4} max={10} step={0.5} value={answers.sleepHours}
            onChange={(v) => handleChange('sleepHours', v)}
            unit="hrs"
        />

        <RangeSlider 
            id="stress"
            label="Recent stress load? (1=Low, 5=High)"
            min={1} max={5} value={answers.stressLevel}
            onChange={(v) => handleChange('stressLevel', v)}
        />
        
        <RangeSlider 
            id="energy"
            label="Recent energy output? (1=Low, 5=High)"
            min={1} max={5} value={answers.energyLevel}
            onChange={(v) => handleChange('energyLevel', v)}
        />
        
        <div>
           <label className="block text-md font-medium text-[color:var(--text-secondary)] mb-2">Fuel Intake Quality?</label>
           <RadioCardGroup
             options={dietOptions}
             selectedValue={answers.dietQuality}
             onChange={(value) => handleChange('dietQuality', value)}
           />
        </div>
        
         <div>
           <label className="block text-md font-medium text-[color:var(--text-secondary)] mb-2">Weekly Activity Output?</label>
           <RadioCardGroup
             options={activityOptions}
             selectedValue={answers.activityLevel}
             onChange={(value) => handleChange('activityLevel', value)}
           />
        </div>

        <button
          type="submit"
          className="w-full text-lg font-bold py-3 px-6 rounded-lg shadow-lg transition-all transform hover:scale-105 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-yellow-500/50
                   relative overflow-hidden group bg-black/30 backdrop-blur-sm"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-yellow-500 to-amber-400 opacity-80 group-hover:opacity-100 transition-opacity duration-300"></div>
          <span className="relative z-10 text-white tracking-wider">Submit & Analyze</span>
        </button>
      </form>
    </div>
  );
};

export default LifestyleQuiz;