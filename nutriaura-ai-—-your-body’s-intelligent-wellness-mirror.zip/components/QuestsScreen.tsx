import React, { useState, useEffect } from 'react';
import { getMissions, completeMission, getCompletedMissions } from '../services/wellnessService';
import type { Mission } from '../types';
import { QuestIcon, AuraPointsIcon } from './icons';

interface QuestsScreenProps {
    onAwardAp: (points: number) => void;
}

const QuestsScreen: React.FC<QuestsScreenProps> = ({ onAwardAp }) => {
    const [missions, setMissions] = useState<Mission[]>([]);
    const [completedMissions, setCompletedMissions] = useState<string[]>([]);
    const [animatedMissionId, setAnimatedMissionId] = useState<string | null>(null);

    useEffect(() => {
        setMissions(getMissions());
        setCompletedMissions(getCompletedMissions());
    }, []);

    const handleCompleteMission = (mission: Mission) => {
        if (completedMissions.includes(mission.id)) return;
        
        onAwardAp(mission.apReward);
        const updatedCompleted = completeMission(mission.id);
        setCompletedMissions(updatedCompleted);

        // Trigger animation for better feedback
        setAnimatedMissionId(mission.id);
        setTimeout(() => {
            setAnimatedMissionId(null);
        }, 600); // Animation duration
    };

    const renderMissionList = (title: string, type: 'daily' | 'weekly') => {
        const filteredMissions = missions.filter(m => m.type === type);
        return (
            <div className="mb-8">
                <h3 className="mb-4">{title}</h3>
                <div className="space-y-3">
                    {filteredMissions.map(mission => {
                        const isCompleted = completedMissions.includes(mission.id);
                        const isAnimating = animatedMissionId === mission.id;
                        return (
                            <div
                                key={mission.id}
                                className={`p-4 rounded-lg flex items-center justify-between gap-4 transition-all duration-500 border ${
                                    isAnimating
                                    ? 'scale-105 bg-white/10 shadow-[0_0_20px_var(--accent-focus)] border-[color:var(--accent-focus)]/50'
                                    : 'bg-black/20 border-[color:var(--text-tertiary)]'
                                }`}
                            >
                                <div className="flex items-start gap-3 flex-grow">
                                    <div className={`p-2 rounded-full transition-colors ${isCompleted ? 'bg-black/20' : 'bg-cyan-500/10'}`}>
                                      <mission.icon className={`w-7 h-7 transition-colors ${isCompleted ? 'text-slate-500' : 'text-cyan-400'}`} />
                                    </div>
                                    <div className={`transition-opacity ${isCompleted && !isAnimating ? 'opacity-50' : ''}`}>
                                        <h4 className="font-semibold text-[color:var(--text-primary)]">{mission.title}</h4>
                                        <p className="text-[color:var(--text-secondary)] text-base">{mission.description}</p>
                                    </div>
                                </div>
                                <div className="flex flex-col items-center gap-1 flex-shrink-0">
                                    <button
                                        onClick={() => handleCompleteMission(mission)}
                                        disabled={isCompleted}
                                        className={`py-2 px-4 rounded-md text-sm font-bold transition whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500 border ${
                                            isCompleted 
                                                ? 'bg-slate-700 text-slate-400 cursor-default border-slate-600' 
                                                : 'bg-cyan-500/80 text-white hover:bg-cyan-600/80 border-cyan-400/50'
                                        }`}
                                    >
                                        {isCompleted ? 'Complete' : 'Execute'}
                                    </button>
                                     <div className={`flex items-center gap-1 text-xs font-bold transition-all duration-500 ${isAnimating ? 'scale-125' : ''} ${isCompleted ? 'text-slate-500' : 'text-yellow-400'}`}>
                                        <AuraPointsIcon className="w-3 h-3" />
                                        <span>+{mission.apReward} AP</span>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        );
    };

    return (
        <div className="w-full">
             <h2 className="glitch mb-2 text-center flex items-center justify-center gap-2" data-text="Mission Log">
                <QuestIcon className="w-8 h-8" />
                Mission Log
            </h2>
            <p className="text-lg text-[color:var(--text-secondary)] mb-6 text-center">Complete missions to earn Aura Points and upgrade your profile.</p>
            <div className="interactive-card">
                {renderMissionList("Daily Missions", "daily")}
                {renderMissionList("Weekly Missions", "weekly")}
            </div>
        </div>
    );
};

export default QuestsScreen;