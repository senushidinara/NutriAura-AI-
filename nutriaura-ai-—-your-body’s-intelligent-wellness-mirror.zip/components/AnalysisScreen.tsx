import React, { useState, useEffect } from 'react';
import { CircuitryIcon } from './icons';

const analysisSteps = [
  "Initializing biometric scanner...",
  "Analyzing facial and skin data points...",
  "Correlating lifestyle data logs...",
  "Identifying potential nutrient imbalances...",
  "Profiling neuro-energy patterns...",
  "Compiling personalized wellness matrix...",
];

const chaosAnalysisSteps = [
  "Accessing the mainframe...",
  "Decompiling wellness secrets from a 1980s movie...",
  "Re-routing power from the flux capacitor...",
  "Shaking the server rack vigorously...",
  "Calculating pizza-to-logic paradox...",
  "Generating hilariously flawed directives...",
];

interface AnalysisScreenProps {
  isChaosMode: boolean;
}

const AnalysisScreen: React.FC<AnalysisScreenProps> = ({ isChaosMode }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const steps = isChaosMode ? chaosAnalysisSteps : analysisSteps;

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStep(prev => (prev + 1) % steps.length);
    }, 2500);
    return () => clearInterval(interval);
  }, [steps.length]);

  return (
    <div className="interactive-card rounded-xl p-6 sm:p-8 text-center flex flex-col items-center">
      <div className="relative w-32 h-32 mb-8 flex items-center justify-center">
        <div className="w-full h-full rounded-full bg-[color:var(--accent-primary-to)]/10 flex items-center justify-center border-2 border-[color:var(--accent-primary-to)]/20">
            <CircuitryIcon className="w-16 h-16 text-[color:var(--accent-primary-to)]" />
        </div>
        <div className="absolute inset-0 rounded-full border-2 border-[color:var(--accent-primary-to)] animate-ping"></div>
        <div className="absolute inset-2 rounded-full border border-[color:var(--accent-primary-to)]/50 animate-pulse"></div>
      </div>
      
      <h2 data-text={isChaosMode ? "Embracing Chaos..." : "Analyzing..."} className="glitch text-3xl font-bold text-[color:var(--text-primary)] mb-2">
        {isChaosMode ? "Embracing Chaos..." : "Analyzing..."}
      </h2>
      
      <div className="h-8 mt-4 w-full max-w-sm text-center">
        <p className="text-[color:var(--text-secondary)] transition-opacity duration-500 animate-fade-in-out" key={currentStep}>
          {steps[currentStep]}
        </p>
      </div>
      
      <style>{`
        @keyframes fade-in-out {
          0%, 100% { opacity: 0; transform: translateY(10px); }
          20%, 80% { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in-out {
          animation: fade-in-out 2.5s infinite cubic-bezier(0.4, 0, 0.2, 1);
        }
      `}</style>
    </div>
  );
};

export default AnalysisScreen;