import React, { useRef, useEffect, useState, useCallback } from 'react';
import { CameraIcon, UploadIcon } from './icons';
import Stepper from './Stepper';

interface CameraCaptureProps {
  onCapture: (imageDataUrl: string) => void;
  imagePreview?: string | null;
  onConfirm?: () => void;
}

const AuroraButton: React.FC<{ onClick: () => void; children: React.ReactNode; className?: string; disabled?: boolean }> = ({ onClick, children, className = '', disabled }) => (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`w-full text-lg font-bold py-3 px-4 rounded-lg shadow-md transition flex items-center justify-center gap-3 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[color:var(--accent-focus)]/50
                 relative overflow-hidden group transform hover:scale-105 bg-black/30
                 disabled:bg-slate-600/50 disabled:cursor-not-allowed disabled:scale-100 disabled:shadow-none
                 ${className}`}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-[color:var(--accent-primary-from)] to-[color:var(--accent-primary-to)] opacity-50 group-hover:opacity-80 transition-opacity duration-300 disabled:opacity-30"></div>
      <span className="relative z-10 text-white tracking-wider">{children}</span>
    </button>
);


const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture, imagePreview = null, onConfirm }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isCameraStarting, setIsCameraStarting] = useState(false);
  const [isCameraReady, setIsCameraReady] = useState(false);

  const stopCameraStream = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
      setIsCameraReady(false);
      setIsCameraStarting(false);
    }
  }, [stream]);

  const startCamera = async () => {
    if (stream) stopCameraStream();
    setError(null);
    setIsCameraStarting(true);
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      let message = "Could not access camera. Please check permissions in your browser settings.";
      if (err instanceof Error && err.name === 'NotAllowedError') {
        message = "Camera access denied. To fix this, please grant camera permission in your browser's address bar (usually a camera icon) and refresh the page.";
      }
      setError(message);
      setIsCameraStarting(false);
    }
  };
  
  const handleCanPlay = () => {
    setIsCameraReady(true);
    setIsCameraStarting(false);
  };

  const handleCapture = useCallback(() => {
    if (videoRef.current && canvasRef.current && isCameraReady) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext('2d');
      if (context) {
        context.translate(canvas.width, 0);
        context.scale(-1, 1);
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
        onCapture(dataUrl);
        stopCameraStream();
      }
    }
  }, [onCapture, isCameraReady, stopCameraStream]);

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        stopCameraStream();
        onCapture(dataUrl);
      };
      reader.readAsDataURL(file);
    }
  };
  
  useEffect(() => {
    return () => stopCameraStream();
  }, [stopCameraStream]);

  const renderInitialState = () => (
    <div className="absolute inset-0 flex flex-col items-center justify-center p-4 gap-4">
        <AuroraButton onClick={startCamera}>
          <CameraIcon className="w-7 h-7" /> Activate Camera
        </AuroraButton>
        <button onClick={handleUploadClick} className="w-full max-w-xs text-lg font-bold py-3 px-4 rounded-lg shadow-md transition flex items-center justify-center gap-3 relative overflow-hidden group transform hover:scale-105 bg-black/30 border border-[color:var(--text-tertiary)] hover:border-[color:var(--text-primary)]">
           <span className="relative z-10 text-white tracking-wider flex items-center gap-3"><UploadIcon className="w-7 h-7" /> Upload Image File</span>
        </button>
    </div>
  );

  const renderCameraView = () => (
    <>
      <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          onCanPlay={handleCanPlay}
          className={`w-full h-full object-cover transform -scale-x-100 transition-opacity duration-500 ${isCameraReady ? 'opacity-100' : 'opacity-0'}`}
      />
      {(isCameraStarting || !isCameraReady) && (
           <div className="absolute inset-0 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm">
              <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-fuchsia-500"></div>
           </div>
      )}
    </>
  );

  const renderPreview = () => (
    <img src={imagePreview!} alt="User submission preview" className="w-full h-full object-cover" />
  );

  return (
    <div className="flex flex-col items-center w-full interactive-card">
        <Stepper currentStep={1} />
        <h2 data-text="Biometric Scan" className="glitch mt-4 mb-2 text-center">Biometric Scan</h2>
        <p className="text-lg text-[color:var(--text-secondary)] mb-4 text-center">Calibrate scanner with a selfie or upload a photo in optimal lighting conditions.</p>
        
        <div className="relative w-full aspect-square max-w-md bg-black/20 rounded-md overflow-hidden shadow-inner border border-white/10">
            {imagePreview ? renderPreview() : stream ? renderCameraView() : renderInitialState()}
        </div>
        
        <canvas ref={canvasRef} className="hidden" />
        <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
        
        <div className="mt-6 w-full max-w-xs flex flex-col gap-3">
          {imagePreview && onConfirm ? (
            <AuroraButton onClick={onConfirm}>
               Confirm & Proceed
            </AuroraButton>
          ) : stream ? (
             <AuroraButton onClick={handleCapture} disabled={!isCameraReady}>
                <CameraIcon className="w-7 h-7" />
                <span>Capture Biometrics</span>
            </AuroraButton>
          ) : null }
        </div>

        {error && <p className="text-sm text-red-400 mt-4 text-center">{error}</p>}
    </div>
  );
};

export default CameraCapture;