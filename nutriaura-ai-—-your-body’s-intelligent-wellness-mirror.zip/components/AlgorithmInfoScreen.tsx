import React from 'react';
import { BrainCircuitIcon, HeartRateIcon } from './icons';

const AlgorithmInfoScreen: React.FC = () => {
    
    const InfoSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
        <div className="mb-6">
            <h3 className="mb-2">{title}</h3>
            <div className="space-y-3 text-[color:var(--text-secondary)]">{children}</div>
        </div>
    );

    const linkClass = "text-[color:var(--accent-focus)] font-semibold hover:underline rounded-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[color:var(--accent-focus)]";

    return (
        <div className="w-full">
            <h2 className="glitch mb-2 text-center flex items-center justify-center gap-2" data-text="AI Core Details">
                <BrainCircuitIcon className="w-8 h-8" />
                AI Core Details
            </h2>
            <p className="text-lg text-[color:var(--text-secondary)] mb-6 text-center">Fostering transparency in our wellness technology.</p>

            <div className="interactive-card rounded-xl p-6 sm:p-8">
                <InfoSection title="🧬 The Core Protocol">
                    <p>
                        NutriAura AI is designed to be your body's intelligent mirror. We combine visual data from your biometric scan with self-reported lifestyle data to create a holistic snapshot of your potential wellness patterns. Our goal is to identify correlations that might otherwise be missed.
                    </p>
                </InfoSection>

                <InfoSection title="📸 Step 1: Biometric Scan">
                    <p>
                        When you provide a photo, our system analyzes it for common visual indicators related to wellness. This is not a medical diagnosis, but a pattern recognition task.
                    </p>
                    <p>
                        The AI scans for cues like:
                    </p>
                    <ul className="list-disc list-inside space-y-1 pl-2">
                        <li><span className="font-semibold text-cyan-300">Skin Luminescence:</span> Signs of dehydration, dullness, or uneven tone.</li>
                        <li><span className="font-semibold text-cyan-300">Fatigue Indicators:</span> The appearance of dark circles or puffiness under the eyes.</li>
                        <li><span className="font-semibold text-cyan-300">Facial Tension:</span> Subtle cues that may relate to stress.</li>
                    </ul>
                </InfoSection>

                <InfoSection title="📝 Step 2: Lifestyle Data Analysis">
                    <p>
                        Your answers to the lifestyle data log provide crucial context. The AI cross-references your visual data with your habits. For example, if the AI detects fatigue indicators and you report sleeping only 5 hours per cycle, it strengthens the confidence of a sleep-related finding.
                    </p>
                </InfoSection>
                
                <InfoSection title="🔮 Step 3: The Gemini Engine">
                    <p>
                        This is where all data streams converge. We send the combined data—the raw image file and quiz answers—to Google's powerful Gemini AI model. 
                    </p>
                    <p>
                        We use a technique called **multimodal prompting**. We provide a specific "persona" (a futuristic wellness expert) and instruct it to synthesize all information and generate your scores, key findings, and recommendations in a structured JSON format. This ensures the output is consistent, relevant, and actionable.
                    </p>
                    <p>
                        You can learn more about the technology at the official <a href="https://deepmind.google/technologies/gemini/" target="_blank" rel="noopener noreferrer" className={linkClass}>Google Gemini page</a>.
                    </p>
                </InfoSection>

                <div className="mt-8 border-t border-[color:var(--accent-focus)]/20 pt-6 text-center">
                    <HeartRateIcon className="w-8 h-8 text-red-400 mx-auto mb-2"/>
                    <h4 className="font-bold text-[color:var(--text-primary)]">Our Scoring Philosophy</h4>
                    <p className="text-sm text-[color:var(--text-secondary)] max-w-md mx-auto mt-1">
                        Our scores are not medical metrics. They are guides to help you build awareness and make mindful choices. NutriAura AI is a tool for wellness exploration, not a substitute for professional medical advice.
                    </p>
                </div>

            </div>
        </div>
    );
};

export default AlgorithmInfoScreen;