import React, { useState } from 'react';
import type { UserProfile, Badge } from '../types';
import { getBadges } from '../services/wellnessService';
import { ProfileIcon, AuraPointsIcon, BrainCircuitIcon } from './icons';

interface ProfileScreenProps {
    profile: UserProfile;
    earnedBadges: string[];
    onNavigateToInfo: () => void;
    currentTheme: string;
    onThemeChange: (theme: string) => void;
}

const themes = [
    { id: 'pastel-lavender', name: 'Lavender Dream', colors: ['#e9defa', '#d1d1f7'] },
    { id: 'pastel-mint', name: 'Minty Fresh', colors: ['#d1fae5', '#cce7ff'] },
    { id: 'pastel-peach', name: 'Peach Sunset', colors: ['#fee2e2', '#ffedd5'] },
    { id: 'aurora-dark', name: 'Living Aurora', colors: ['#f0f', '#0cf'] },
];

const BadgeDetailModal: React.FC<{ badge: Badge | null; onClose: () => void; }> = ({ badge, onClose }) => {
    if (!badge) return null;

    return (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div className="interactive-card rounded-xl p-6 sm:p-8 max-w-sm w-full text-center relative animate-slide-in" onClick={(e) => e.stopPropagation()}>
                <button onClick={onClose} className="absolute top-4 right-4 text-2xl leading-none text-[color:var(--text-secondary)] hover:text-[color:var(--text-primary)] transition rounded-full w-8 h-8 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[color:var(--accent-focus)]">&times;</button>
                
                <div className="w-24 h-24 mx-auto mb-4 rounded-full flex items-center justify-center bg-yellow-500/10 border-2 border-yellow-500/20" style={{boxShadow: '0 0 20px rgba(234, 179, 8, 0.3)'}}>
                    <badge.icon className="w-12 h-12 text-yellow-400" />
                </div>
                
                <h3 className="text-yellow-300">{badge.title}</h3>
                
                <p className="mt-2 text-[color:var(--text-secondary)]">
                    {badge.description}
                </p>

                <button onClick={onClose} className="mt-6 w-full bg-cyan-500 text-white font-bold py-2 px-4 rounded-md shadow-md hover:bg-cyan-600 transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500">
                    Close
                </button>
            </div>
        </div>
    );
};


const ProfileScreen: React.FC<ProfileScreenProps> = ({ profile, earnedBadges, onNavigateToInfo, currentTheme, onThemeChange }) => {
    const allBadges = getBadges();
    const progressPercent = (profile.ap / profile.apForNextLevel) * 100;
    const [selectedBadge, setSelectedBadge] = useState<Badge | null>(null);

    return (
        <div className="w-full text-center">
            <BadgeDetailModal badge={selectedBadge} onClose={() => setSelectedBadge(null)} />
            <h2 className="glitch mb-2 flex items-center justify-center gap-2" data-text="Agent Profile">
                <ProfileIcon className="w-8 h-8"/>
                Agent Profile
            </h2>
            <p className="text-lg text-[color:var(--text-secondary)] mb-6">Your wellness journey and achievements.</p>

            <div className="interactive-card mb-8">
                 <h3 className="mb-4">Customize Theme</h3>
                 <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                     {themes.map(theme => (
                         <button
                             key={theme.id}
                             onClick={() => onThemeChange(theme.id)}
                             className={`p-2 rounded-lg text-center transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 ring-offset-2 ring-offset-[color:var(--bg-secondary)] ring-[color:var(--accent-focus)] ${currentTheme === theme.id ? 'transform scale-105' : 'hover:scale-105'}`}
                         >
                             <div className={`w-full h-12 rounded-md mb-2 flex items-center justify-center border-2 ${currentTheme === theme.id ? 'border-white' : 'border-transparent'}`} style={{ background: `linear-gradient(45deg, ${theme.colors[0]}, ${theme.colors[1]})` }}>
                                {currentTheme === theme.id && <div className="w-6 h-6 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center text-white shadow-lg">&#10003;</div>}
                             </div>
                             <p className="text-sm font-medium text-[color:var(--text-secondary)]">{theme.name}</p>
                         </button>
                     ))}
                 </div>
            </div>

            <div className="interactive-card">
                {/* Level and AP */}
                <div className="p-6 rounded-md mb-8 bg-black/5 dark:bg-black/20 shadow-inner">
                    <div className="flex justify-between items-baseline mb-2">
                        <span className="text-lg font-bold text-[color:var(--accent-primary-to)]">Level {profile.level}</span>
                        <span className="text-base text-[color:var(--text-secondary)] flex items-center gap-1">
                            <AuraPointsIcon className="w-4 h-4 text-yellow-400"/> {profile.ap} / {profile.apForNextLevel} AP
                        </span>
                    </div>
                    <div className="w-full bg-black/10 dark:bg-black/30 rounded-full h-4 overflow-hidden border border-[color:var(--card-border)]">
                        <div
                            className="bg-gradient-to-r from-[color:var(--accent-primary-from)] to-[color:var(--accent-primary-to)] h-full rounded-full transition-all duration-500"
                            style={{ width: `${progressPercent}%`, boxShadow: `0 0 10px var(--accent-primary-from), 0 0 15px var(--accent-primary-to)` }}
                        ></div>
                    </div>
                </div>

                {/* Badges */}
                <div className="mb-8">
                    <h3 className="mb-4">Achievements</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                        {allBadges.map(badge => {
                            const isEarned = earnedBadges.includes(badge.id);
                            return (
                                <button 
                                    key={badge.id}
                                    onClick={() => isEarned && setSelectedBadge(badge)}
                                    disabled={!isEarned}
                                    className={`p-4 rounded-lg text-center transition focus:outline-none focus-visible:ring-2 focus-visible:ring-yellow-500 border relative ${
                                        isEarned 
                                        ? 'bg-yellow-500/5 border-yellow-500/20 cursor-pointer hover:scale-105 hover:shadow-[0_0_25px_rgba(234,179,8,0.4)]' 
                                        : 'bg-black/10 dark:bg-black/20 border-[color:var(--text-tertiary)] opacity-50 cursor-not-allowed'
                                    }`}
                                >
                                    {isEarned && <div className="absolute -inset-px rounded-lg bg-gradient-to-r from-yellow-500 to-amber-400 opacity-30 -z-10"></div>}
                                    <div className={`w-16 h-16 mx-auto mb-2 rounded-full flex items-center justify-center ${isEarned ? 'bg-yellow-500/10' : 'bg-black/5 dark:bg-black/20'}`}>
                                        <badge.icon className={`w-8 h-8 ${isEarned ? 'text-yellow-400' : 'text-slate-500'}`} />
                                    </div>
                                    <h4 className={`font-bold text-lg ${isEarned ? 'text-yellow-400' : 'text-[color:var(--text-secondary)]'}`}>{badge.title}</h4>
                                </button>
                            );
                        })}
                    </div>
                </div>

                {/* Algorithm Info Button */}
                <div className="border-t border-[color:var(--card-border)] pt-6">
                     <button 
                        onClick={onNavigateToInfo}
                        className="w-full text-left p-4 bg-black/5 dark:bg-black/20 hover:bg-black/10 dark:hover:bg-white/5 border border-[color:var(--card-border)] hover:border-[color:var(--accent-primary-to)] rounded-lg flex items-center justify-between transition-colors focus-visible:outline-none focus-visible:ring-2 ring-[color:var(--accent-focus)]"
                    >
                        <div className="flex items-center gap-3">
                            <BrainCircuitIcon className="w-7 h-7 text-[color:var(--accent-primary-to)]"/>
                            <div>
                                <h4 className="font-semibold">AI Core Details</h4>
                                <p className="text-sm text-[color:var(--text-secondary)]">Learn about our technology.</p>
                            </div>
                        </div>
                        <span className="text-[color:var(--text-tertiary)]">&rarr;</span>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ProfileScreen;