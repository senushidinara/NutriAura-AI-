import React from 'react';
import { CircuitryIcon, PizzaIcon } from './icons';

interface WelcomeScreenProps {
  onStart: () => void;
  isChaosMode: boolean;
}

const AuroraButton: React.FC<{ onClick: () => void; children: React.ReactNode; isChaos?: boolean; }> = ({ onClick, children, isChaos }) => {
  return (
    <button
      onClick={onClick}
      className="w-full max-w-xs text-lg font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[color:var(--accent-focus)]/50
                 relative overflow-hidden group bg-black/30"
    >
      <div className="absolute inset-0 bg-gradient-to-r from-[color:var(--accent-primary-from)] to-[color:var(--accent-primary-to)] opacity-50 group-hover:opacity-80 transition-opacity duration-300"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(255,255,255,0.2)_0%,_rgba(255,255,255,0)_60%)] opacity-50 group-hover:opacity-100 transition-opacity"></div>
      <span className="relative z-10 text-white tracking-wider">{children}</span>
    </button>
  );
};

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onStart, isChaosMode }) => {
  return (
    <div className="interactive-card text-center flex flex-col items-center">
      <div className="mb-6 p-6 rounded-full bg-gradient-to-br from-[color:var(--accent-primary-from)]/10 to-[color:var(--accent-primary-to)]/10" style={{boxShadow: '0 0 30px var(--accent-primary-from), 0 0 30px var(--accent-primary-to)'}}>
        {isChaosMode ? <PizzaIcon className="w-16 h-16 text-red-500" /> : <CircuitryIcon className="w-16 h-16 text-[color:var(--accent-primary-from)]" />}
      </div>
      <h2 className="text-4xl font-extrabold text-[color:var(--text-primary)] mb-2 glitch" data-text={isChaosMode ? "NutriAura: Chaos Protocol" : "NutriAura AI"}>
        {isChaosMode ? "NutriAura: Chaos Protocol" : "NutriAura AI"}
      </h2>
      <p className="text-lg text-[color:var(--text-secondary)] mb-8 max-w-md">
        {isChaosMode ? "System integrity compromised. Engage chaotic subroutines. Probability of pizza-related anomalies: 98.7%." : "Initiate biometric scan. Analyze lifestyle data. Generate your personalized wellness matrix."}
      </p>
      
      <AuroraButton onClick={onStart} isChaos={isChaosMode}>
        {isChaosMode ? "Engage Chaos" : "Begin Analysis"}
      </AuroraButton>

      <p className="text-sm text-[color:var(--text-tertiary)] mt-6 max-w-sm">
        Disclaimer: NutriAura AI provides wellness suggestions and is not a substitute for professional medical advice, diagnosis, or treatment. Chaos Mode is not a substitute for professional comedy.
      </p>
    </div>
  );
};

export default WelcomeScreen;