import React from 'react';
import { CameraIcon, CircuitryIcon, QuestIcon } from './icons';

interface StepperProps {
  currentStep: number;
}

const stepDetails = [
  { name: 'Scan', icon: CameraIcon },
  { name: 'Data Input', icon: CircuitryIcon },
  { name: 'Matrix', icon: QuestIcon },
];

const Stepper: React.FC<StepperProps> = ({ currentStep }) => {
  return (
    <div className="w-full max-w-xs mx-auto">
      <div className="flex items-center justify-between">
        {stepDetails.map((step, index) => {
          const stepIndex = index + 1;
          const isCompleted = currentStep > stepIndex;
          const isActive = currentStep === stepIndex;

          return (
            <React.Fragment key={step.name}>
              <div className="flex flex-col items-center text-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300
                    ${isActive ? 'bg-cyan-500/20 border-cyan-500 shadow-[0_0_10px_rgba(0,186,255,0.5)]' : ''}
                    ${isCompleted ? 'bg-cyan-500/20 border-cyan-500' : ''}
                    ${!isActive && !isCompleted ? 'bg-slate-800 border-slate-700' : ''}
                  `}
                >
                  <step.icon
                    className={`w-6 h-6
                      ${isActive ? 'text-cyan-300' : ''}
                      ${isCompleted ? 'text-cyan-400' : ''}
                      ${!isActive && !isCompleted ? 'text-slate-500' : ''}
                    `}
                  />
                </div>
                <p
                  className={`mt-2 text-xs font-semibold transition-colors duration-300
                    ${isActive ? 'text-cyan-300' : ''}
                    ${isCompleted ? 'text-slate-300' : ''}
                    ${!isActive && !isCompleted ? 'text-slate-500' : ''}
                  `}
                >
                  {step.name}
                </p>
              </div>
              {index < stepDetails.length - 1 && (
                <div
                  className={`flex-1 h-1 mx-2 rounded-full transition-colors duration-500
                    ${currentStep > stepIndex ? 'bg-cyan-500' : 'bg-slate-700'}
                  `}
                />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};

export default Stepper;