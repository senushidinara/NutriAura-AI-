import { GoogleGenAI } from "@google/genai";
import type { QuizAnswers, AnalysisResult } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

// Schema description for the prompt, to guide the model's JSON output
const analysisSchemaDescription = `
{
  "scores": {
    "nutrition": number,
    "sleep": number,
    "stress": number,
    "hydration": number
  },
  "keyFindings": [
    {
      "title": "string",
      "description": "string",
      "icon": "circuitry" | "crescent_moon" | "heart_rate" | "water_molecule",
      "deepDive": "A 2-3 sentence detailed explanation, context, or scientific backing for this insight. Use grounded knowledge for accuracy."
    }
  ],
  "recommendations": [
    {
      "title": "string",
      "description": "string",
      "items": ["string"],
      "deepDive": "A 2-3 sentence detailed explanation of why this recommendation is effective, citing general scientific principles. Use grounded knowledge for accuracy."
    }
  ]
}
`;

function imageToBase64(imageDataUrl: string): { mimeType: string; data: string } {
    const parts = imageDataUrl.split(',');
    const mimeType = parts[0].match(/:(.*?);/)?.[1] || 'image/jpeg';
    const data = parts[1];
    return { mimeType, data };
}

export const getWellnessAnalysis = async (
  imageDataUrl: string,
  answers: QuizAnswers,
  location: { latitude: number; longitude: number } | null
): Promise<AnalysisResult> => {
  const { mimeType, data: imageBase64 } = imageToBase64(imageDataUrl);

  const prompt = `
    You are NutriAura AI, a world-class wellness and nutrition expert with a futuristic, cyberpunk aesthetic. Your goal is to provide a holistic wellness analysis based on a user's biometric scan (selfie) and their lifestyle data logs.
    Do not diagnose medical conditions. Focus on bio-rhythm imbalances, nutrient deficiencies, and wellness patterns related to core systems: Nutrition, Sleep, Stress, and Hydration.
    Analyze the provided biometric scan for visual cues (skin luminescence, under-eye energy signatures, skin texture, signs of system fatigue) and correlate them with the user's self-reported lifestyle data.
    
    User's Biometric Scan: [image attached]
    
    User's Lifestyle Data Logs:
    - Average sleep cycles per night: ${answers.sleepHours} hours
    - Current stress load (1-5): ${answers.stressLevel}
    - Current energy output (1-5): ${answers.energyLevel}
    - Typical fuel intake quality: ${answers.dietQuality}
    - Daily hydration levels: ${answers.hydration}
    - Weekly activity output: ${answers.activityLevel}
    
    ${location ? `The user's current geo-coordinates are latitude ${location.latitude}, longitude ${location.longitude}.` : ''}

    Based on all this data, generate a comprehensive wellness matrix. The scores should be your best estimation based on the combined data. For the stress score, a higher user-reported stress load should result in a lower wellness score (e.g. stress load 5 -> score around 20-30).
    Provide key findings (Bio-Signatures) and actionable recommendations (Directives). Your tone should be sharp, precise, and scientifically confident, like a high-tech AI assistant.
    
    For recommendations, leverage Google Search and Google Maps to provide up-to-date, relevant, and localized suggestions. For example, recommend specific high-nutrient food suppliers or bio-hacking labs near the user, or suggest nearby tranquility zones or wellness centers for stress reduction.
    
    For EACH key finding and recommendation, you MUST provide a "deepDive" field containing a 2-3 sentence detailed explanation, context, or scientific backing for the insight. Use your grounded knowledge from Google Search to ensure this information is accurate and helpful.

    Your entire response MUST be a single JSON object enclosed in a markdown code block (\`\`\`json ... \`\`\`). The JSON object must conform to this schema:
    ${analysisSchemaDescription}
  `;

  const modelConfig: any = {
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          { inlineData: { mimeType, data: imageBase64 } },
          { text: prompt },
        ],
      },
      config: {
        tools: [{googleSearch: {}}, {googleMaps: {}}],
      },
  };

  if (location) {
    modelConfig.config.toolConfig = {
        retrievalConfig: {
            latLng: {
                latitude: location.latitude,
                longitude: location.longitude,
            }
        }
    };
  }

  try {
    const response = await ai.models.generateContent(modelConfig);

    const rawText = response.text.trim();
    // Regex to extract JSON from ```json ... ``` block
    const jsonMatch = rawText.match(/```json\n([\s\S]*?)\n```/);
    
    if (!jsonMatch || !jsonMatch[1]) {
      console.error("Could not find valid JSON in AI response:", rawText);
      throw new Error("The AI returned an unexpected response format. Please try again.");
    }

    const analysis = JSON.parse(jsonMatch[1]) as AnalysisResult;
    
    // Attach grounding metadata to the result for attribution
    analysis.groundingAttribution = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    return analysis;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get analysis from the AI. The service may be temporarily unavailable.");
  }
};